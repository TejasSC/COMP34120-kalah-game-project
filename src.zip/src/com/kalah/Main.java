package com.kalah;
import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

/**
 * The main application class. It also provides methods for communication
 * with the game engine.
 */
public class Main
{
    /**
     * Input from the game engine.
     */
    private static Reader input = new BufferedReader(new InputStreamReader(System.in));

    /**
     * Sends a message to the game engine.
     * @param msg The message.
     */
    public static void sendMsg (String msg)
    {
    	System.out.print(msg);
    	System.out.flush();
    }

    /**
     * Receives a message from the game engine. Messages are terminated by
     * a '\n' character.
     * @return The message.
     * @throws IOException if there has been an I/O error.
     */
    public static String recvMsg() throws IOException
    {
    	StringBuilder message = new StringBuilder();
    	int newCharacter;

    	do
    	{
    		newCharacter = input.read();
    		if (newCharacter == -1)
    			throw new EOFException("Input ended unexpectedly.");
    		message.append((char)newCharacter);
    	} while((char)newCharacter != '\n');

		return message.toString();
    }

	/**
	 * The main method, invoked when the program is started.
	 * @param args Command line arguments.
	 */
	public static void main(String[] args) throws FileNotFoundException {
//		PrintStream out = new PrintStream(
//				new FileOutputStream("output.txt"), true);
//		System.setErr(out);
		try
		{
			String s;
			boolean south = false;
			while (true)
			{
				System.err.println();
				s = recvMsg();
				System.err.print("Received: " + s);
				try {
					MsgType mt = Protocol.getMessageType(s);
					switch (mt)
					{
						case START: System.err.println("A start.");
							south = Protocol.interpretStartMsg(s);
							System.err.println("Starting player? " + south);

							// if we are the starting player - make a move
							// we choose the hole closest to the well
							// create move message
							if (south) {
								String firstMessage = Protocol.createMoveMsg(1);
								sendMsg(firstMessage);
							}
							break;
						case STATE: System.err.println("A state.");
							Board b = new Board(7,7);
							Protocol.MoveTurn r = Protocol.interpretStateMsg (s, b);
							System.err.println("This was the move: " + r.move);
							System.err.println("Is the game over? " + r.end);

							if (r.end)
								break;

							System.err.println("Is it our turn again? " + r.again);
							System.err.print("The board:\n" + b);

							// swap
							if (r.move == -1) {
								System.err.print("swapping :\n" + b);
								south = !south;
//								break;
							}

							// if not our move
							if (!r.again){
								break;
							}

							// create a new move
							Kalah game = new Kalah(b);

							// construct a side
							Side side = Side.NORTH;
							if (south)
								side = Side.SOUTH;

							// construct a list of legal moves
							ArrayList<Integer> options = new ArrayList<Integer>();
							for (int i = 1; i < 8; i++){
								Move move = new Move(side, i);
								if (game.isLegalMove(move))
									options.add(i);
							}

							// wrong side
							if (options.size() == 0) {
								System.err.println("we were on the wrong side");
								side = side.opposite();

								// construct a list of legal moves
								for (int i = 1; i < 8; i++){
									Move move = new Move(side, i);
									if (game.isLegalMove(move))
										options.add(i);
								}
							}

							System.err.println("available moves: " + options.toString());

							// for every option check if it gives extra turns
							ArrayList<Integer> extraMoves = new ArrayList<Integer>();
							for (int h : options) {
								// create a move
								Move move = new Move(side, h);
								// create game object
								game = new Kalah(b);
								// test the move
								Side resultingSide = game.makeMove(move);
								// if we get an extra turn append it to the list
								if (resultingSide == side)
									extraMoves.add(h);
							}
							System.err.println("extra moves: " + extraMoves.toString());
							Random random = new Random();

							// if we have any moves that result in an extra move
							int result;
							if (extraMoves.size() != 0)
								result = extraMoves.get(random.nextInt(extraMoves.size()));
							else
								result = options.get(random.nextInt(options.size()));

							// print the choosen move
							System.err.println("choosen move: " + result);

							// create move message
							String message = Protocol.createMoveMsg(result);
							sendMsg(message);
							break;
						case END: System.err.println("An end. Bye bye!"); return;
					}

				} catch (InvalidMessageException e) {
					System.err.println(e.getMessage());
				}
			}
		}
		catch (IOException e)
		{
			System.err.println("This shouldn't happen: " + e.getMessage());
		}
	}

	public static int evaluate(Board board)
	{
		int seedsInNorthWell = board.getSeedsInStore(Side.NORTH);
		int seedsInSouthWell = board.getSeedsInStore(Side.SOUTH);

		if(seedsInSouthWell > seedsInNorthWell) return -10;
		else if(seedsInSouthWell < seedsInNorthWell) return 10;
		else return 0;
	}

	// Initial values of
	// Aplha and Beta
	static int MAX = 1000;
	static int MIN = -1000;
	static int MAX_DEPTH = 15;

	public static int minimax(Board board, int depth, boolean isMax, Side side, int alpha, int beta) throws CloneNotSupportedException {
		if (depth > MAX_DEPTH)
			return 0;

		int score = evaluate(board);

		Kalah game = new Kalah(board);

		if (score == 10) return score;
		if (score == -10) return score;
		if (game.gameOver()) return 0;

		//int sideMin;
		//if (isMax) side == 1? sideMin = 0 : sideMin = 1;
		//else sideMin = side;

		if (isMax)
		{
			int best = MIN;

			for (int i = 1; i < 7; i++)
			{
				int number = board.getSeeds(side, i);

				if(number != 0)
				{
					int k = 1;
					while(k < number)
					{
						int index = i + k;
						if(i == 6) index = 0;
						board.addSeeds(side, index, 1);
						k++;
					}

					best = Math.max(best, minimax(board.clone(), depth + 1, !isMax, side,  alpha, beta));
					alpha = Math.max(alpha, best);

					// Alpha Beta Pruning
					if (beta <= alpha)
						break;

					while(i < k)
					{
						int index = i + k;
						int orgNum = board.getSeeds(side, index);
						board.setSeeds(side, index, orgNum - 1);
						k--;
					}
				}
			}
			return best;
		}
		else
		{
			int best = MAX;

			for (int i = 1; i < 7; i++)
			{
				int number = board.getSeedsOp(side, i);

				if(number != 0)
				{
					int k = 1;
					while(k < number)
					{
						board.addSeedsOp(side.opposite(), i + k, 1);
						k++;
					}

					best = Math.min(best, minimax(board.clone(), depth + 1, !isMax, side,  alpha, beta));
					beta = Math.min(beta, best);

					// Alpha Beta Pruning
					if (beta <= alpha)
						break;

					while(i < k)
					{
						int index = i + k;
						int orgNum = board.getSeeds(side.opposite(), index);
						board.setSeeds(side.opposite(), index, orgNum - 1);
						k--;
					}
				}
			}

			return best;
		}
	}

	public static Move findBestMove(Board board, Side side) throws CloneNotSupportedException {
		int bestVal = -1000;
		Move bestMove = new Move(side, 1);
		boolean found = false;

		for (int i = 1; i < 7; i++)
		{
			int number = board.getSeedsOp(side, i);
			if(number != 0)
			{
				int k = 1;
				int moveVal = minimax(board.clone(), 0, false, side, MIN, MAX);

				if (moveVal > bestVal)
				{
					bestMove = new Move(side, i);
					bestVal = moveVal;
					found = true;
				}
			}
		}

		if (!found)
			return null;
		return bestMove;
	}
}
